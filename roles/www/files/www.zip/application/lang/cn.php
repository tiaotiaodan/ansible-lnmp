<?php

return array (
  'sys1' => '首页',
  'sys2' => '上一页',
  'sys3' => '下一页',
  'sys4' => '末页',
  'sys5' => '共<strong>%s</strong>页 <strong>%s</strong>条',
  'sys6' => '全部',
  'sys7' => '搜索',
  'sys8' => '查看详情',
  'sys9' => '网站首页',
  'sys10' => '暂无',
  'sys11' => '上一篇',
  'sys12' => '下一篇',
);