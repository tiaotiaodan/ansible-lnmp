<?php

return array (
  'sys1' => 'Home',
  'sys2' => 'Previous',
  'sys3' => 'Next',
  'sys4' => 'Last',
  'sys5' => 'Road <strong>%s</strong> page <strong>%s</strong> strip',
  'sys6' => 'All',
  'sys7' => 'Search',
  'sys8' => 'View details',
  'sys9' => 'Home',
  'sys10' => 'No time',
  'sys11' => 'Previous',
  'sys12' => 'Next',
);