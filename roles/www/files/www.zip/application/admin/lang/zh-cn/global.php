<?php
return array(
    'open'  => '开启',
    'close' => '关闭',
    'successful_operation'  => '操作成功',
    'operation_failed' => '操作失败',
    'select_upload'    => '选择上传...',
    'select_upload_msg'  => '点击前方预览图可查看大图，点击按钮选择文件并提交表单后上传生效',
    'submit'	=> '确认提交',
    'being_dealt_with'	=> '正在处理',
    'operation_hints' => '操作提示',
    'operation_hints_title' => '提示相关设置操作时应注意的要点',
    'pick_up_a_hint' => '收起提示',
    'web_setting' => '网站设置',
    'web_setting_notic' => '网站全局内容基本选项设置',
    'minute'	=> '分钟',
);