<?php
return array(
    'index' => array(
        // 'web_name'      => '网站名称',
        // 'web_logo'      => '网站Logo',
        // 'web_logo_notic'  => '默认网站LOGO,通用头部显示，最佳显示尺寸 180 * 60 (像素)',
        // 'web_ico'  => '浏览器地址栏图标',
        // 'web_ico_notic' => '建议尺寸 32 * 32 (像素) 的.ico文件。<a href="https://www.baidu.com/s?wd=ico%E5%9B%BE%E6%A0%87%E5%88%B6%E4%BD%9C" target="_blank">点击制作ICO</a><br/>如果无法正常显示新上传图标，清空浏览器缓存后访问。',
        // 'web_url'	=> '网站网址',
        // 'web_keyword'	=> '网站关键词',
        // 'web_keyword_notic' => '多个关键词请用逗号,隔开，建议3到4个关键词。',
        // 'web_desc'	=> '网站描述',
        // 'web_bottom_navtitle' => '网站底部信息设置',
        // 'web_copyright'	=> '版权信息',
        // 'web_thirdcode_pc' => '第三方代码（电脑PC端）',
        // 'web_thirdcode_notic_pc'	=> '代码会放在 &lt;/body&gt; 标签以上（一般用于放置百度商桥代码、站长统计代码、谷歌翻译代码等）',
        // 'web_thirdcode_wap' => '第三方代码（手机移动端）',
        // 'web_thirdcode_notic_wap'	=> '代码会放在 &lt;/body&gt; 标签以上（一般用于放置百度商桥代码、站长统计代码、谷歌翻译代码等）',
        // 'operation_hints_info' => '系统平台全局设置，包括基础设置、短信、邮件、水印和对象存储等相关模块。',
        // 'web_address' => '联系地址',
        // 'web_contact' => '联系方式',
    ),
);